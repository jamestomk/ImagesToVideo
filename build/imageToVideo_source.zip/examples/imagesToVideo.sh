#!/bins/sh
# this file would normally be install in a users run $PATH such as /usr/home/$USERNAME/bin
java -jar "C:/Program Files/Java/imageToVideo.jar" $*